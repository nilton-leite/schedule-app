import 'package:flutter/material.dart';
import 'backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _authorization = prefs.getString('ff_authorization') ?? _authorization;
    });
    _safeInit(() {
      _userId = prefs.getInt('ff_userId') ?? _userId;
    });
    _safeInit(() {
      _userName = prefs.getString('ff_userName') ?? _userName;
    });
    _safeInit(() {
      _doctorId = prefs.getInt('ff_doctorId') ?? _doctorId;
    });
    _safeInit(() {
      _doctorName = prefs.getString('ff_doctorName') ?? _doctorName;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  String _authorization = '';
  String get authorization => _authorization;
  set authorization(String _value) {
    _authorization = _value;
    prefs.setString('ff_authorization', _value);
  }

  int _userId = 0;
  int get userId => _userId;
  set userId(int _value) {
    _userId = _value;
    prefs.setInt('ff_userId', _value);
  }

  String _userName = '';
  String get userName => _userName;
  set userName(String _value) {
    _userName = _value;
    prefs.setString('ff_userName', _value);
  }

  int _doctorId = 0;
  int get doctorId => _doctorId;
  set doctorId(int _value) {
    _doctorId = _value;
    prefs.setInt('ff_doctorId', _value);
  }

  String _doctorName = '';
  String get doctorName => _doctorName;
  set doctorName(String _value) {
    _doctorName = _value;
    prefs.setString('ff_doctorName', _value);
  }
}

LatLng? _latLngFromString(String? val) {
  if (val == null) {
    return null;
  }
  final split = val.split(',');
  final lat = double.parse(split.first);
  final lng = double.parse(split.last);
  return LatLng(lat, lng);
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
