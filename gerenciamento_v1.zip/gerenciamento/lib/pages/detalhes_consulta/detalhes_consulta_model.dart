import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'detalhes_consulta_widget.dart' show DetalhesConsultaWidget;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DetalhesConsultaModel extends FlutterFlowModel<DetalhesConsultaWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for textField_observacao widget.
  FocusNode? textFieldObservacaoFocusNode;
  TextEditingController? textFieldObservacaoController;
  String? Function(BuildContext, String?)?
      textFieldObservacaoControllerValidator;
  // State field(s) for DropDown widget.
  int? dropDownValue;
  FormFieldController<int>? dropDownValueController;
  // Stores action output result for [Backend Call - API (Update schedule)] action in Button widget.
  ApiCallResponse? apiResult2yq;
  // Stores action output result for [Backend Call - API (Create Query)] action in Button widget.
  ApiCallResponse? apiResultnbp;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {
    unfocusNode.dispose();
    textFieldObservacaoFocusNode?.dispose();
    textFieldObservacaoController?.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
