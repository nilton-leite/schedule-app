import 'dart:convert';
import 'dart:typed_data';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class GetSchedulesCall {
  static Future<ApiCallResponse> call({
    String? doctorId = '8',
    String? statusId = '',
    String? authorization = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Get Schedules',
      apiUrl: 'http://prhgeb.hospedagemelastica.com.br/schedules/only/app',
      callType: ApiCallType.GET,
      headers: {
        'Authorization': 'Bearer ${authorization}',
      },
      params: {
        'doctorId': doctorId,
        'statusId': statusId,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
    );
  }
}

class GetProfileCall {
  static Future<ApiCallResponse> call({
    String? doctorId = '8',
    String? authorization = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Get Profile',
      apiUrl: 'http://prhgeb.hospedagemelastica.com.br/doctors/app/${doctorId}',
      callType: ApiCallType.GET,
      headers: {
        'Authorization': 'Bearer ${authorization}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
    );
  }
}

class AuthCall {
  static Future<ApiCallResponse> call({
    String? username = '',
    String? password = '',
  }) async {
    final ffApiRequestBody = '''
{
  "username": "${username}",
  "password": "${password}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Auth',
      apiUrl: 'http://prhgeb.hospedagemelastica.com.br/auth',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
    );
  }
}

class GetAllSchedulesCall {
  static Future<ApiCallResponse> call({
    String? doctorId = '8',
    String? authorization = '',
    String? data = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Get all Schedules',
      apiUrl: 'http://prhgeb.hospedagemelastica.com.br/schedules/only/app',
      callType: ApiCallType.GET,
      headers: {
        'Authorization': 'Bearer ${authorization}',
      },
      params: {
        'doctorId': doctorId,
        'data': data,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
    );
  }
}

class GetStatusCall {
  static Future<ApiCallResponse> call({
    String? authorization = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Get status',
      apiUrl: 'http://prhgeb.hospedagemelastica.com.br/status',
      callType: ApiCallType.GET,
      headers: {
        'Authorization': 'Bearer ${authorization}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
    );
  }
}

class GetPatientsCall {
  static Future<ApiCallResponse> call({
    String? authorization = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Get Patients',
      apiUrl: 'http://prhgeb.hospedagemelastica.com.br/patients/app',
      callType: ApiCallType.GET,
      headers: {
        'Authorization': 'Bearer ${authorization}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
    );
  }

  static dynamic response(dynamic response) => getJsonField(
        response,
        r'''$.response''',
        true,
      );
}

class CreateScheduleCall {
  static Future<ApiCallResponse> call({
    String? data = '',
    String? time = '',
    bool? hasFirstQuery,
    int? patientId,
    int? doctorId,
    String? authorization = '',
    int? statusId = 2,
    bool? hasHealthInsurance,
  }) async {
    final ffApiRequestBody = '''
{
  "data": "${data}",
  "time": "${time}",
  "hasFirstQuery": ${hasFirstQuery},
  "patientId": ${patientId},
  "doctorId": ${doctorId},
  "statusId": ${statusId},
  "hasHealthInsurance": ${hasHealthInsurance}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Create schedule',
      apiUrl: 'http://prhgeb.hospedagemelastica.com.br/schedules',
      callType: ApiCallType.POST,
      headers: {
        'Authorization': 'Bearer ${authorization}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
    );
  }
}

class UpdateScheduleCall {
  static Future<ApiCallResponse> call({
    int? scheduleId,
    String? authorization = '',
    int? statusId,
  }) async {
    final ffApiRequestBody = '''
{
  "statusId": ${statusId}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Update schedule',
      apiUrl: 'http://prhgeb.hospedagemelastica.com.br/schedules/${scheduleId}',
      callType: ApiCallType.PATCH,
      headers: {
        'Authorization': 'Bearer ${authorization}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
    );
  }
}

class CreateQueryCall {
  static Future<ApiCallResponse> call({
    String? authorization = '',
    String? obs = '',
    int? scheduleId,
  }) async {
    final ffApiRequestBody = '''
{
  "obs": "${obs}",
  "scheduleId": ${scheduleId}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Create Query',
      apiUrl: 'http://prhgeb.hospedagemelastica.com.br/queries',
      callType: ApiCallType.POST,
      headers: {
        'Authorization': 'Bearer ${authorization}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
    );
  }
}

class UpdatePasswordCall {
  static Future<ApiCallResponse> call({
    String? authorization = '',
    String? password = '',
    int? userId,
  }) async {
    final ffApiRequestBody = '''
{
  "userId": ${userId},
  "password": "${password}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Update Password',
      apiUrl: 'http://prhgeb.hospedagemelastica.com.br/users/password',
      callType: ApiCallType.PUT,
      headers: {
        'Authorization': 'Bearer ${authorization}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
    );
  }
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list);
  } catch (_) {
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar);
  } catch (_) {
    return isList ? '[]' : '{}';
  }
}
