import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAWd19hRhHTr16QvEdFheOeu3MqY-hH4fM",
            authDomain: "agenda-l4az29.firebaseapp.com",
            projectId: "agenda-l4az29",
            storageBucket: "agenda-l4az29.appspot.com",
            messagingSenderId: "852308670085",
            appId: "1:852308670085:web:9b496bc26291cdb27fdbec"));
  } else {
    await Firebase.initializeApp();
  }
}
