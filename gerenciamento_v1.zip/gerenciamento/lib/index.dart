// Export pages
export '/pages/logged_page/logged_page_widget.dart' show LoggedPageWidget;
export '/pages/entry_page/entry_page_widget.dart' show EntryPageWidget;
export '/pages/home/home_widget.dart' show HomeWidget;
export '/pages/detalhes_consulta/detalhes_consulta_widget.dart'
    show DetalhesConsultaWidget;
export '/pages/nova_consulta/nova_consulta_widget.dart' show NovaConsultaWidget;
export '/pages/perfil/perfil_widget.dart' show PerfilWidget;
export '/pages/page_success/page_success_widget.dart' show PageSuccessWidget;
