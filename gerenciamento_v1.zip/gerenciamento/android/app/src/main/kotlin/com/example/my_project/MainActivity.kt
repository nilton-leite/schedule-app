package schedule.manager

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
